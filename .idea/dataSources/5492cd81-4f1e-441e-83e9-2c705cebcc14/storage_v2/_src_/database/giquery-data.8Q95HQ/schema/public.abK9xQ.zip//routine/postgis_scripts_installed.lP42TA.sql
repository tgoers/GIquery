create function postgis_scripts_installed()
  returns text
immutable
language sql
as $$
SELECT '2.3.7'::text || ' r' || 16523::text AS version
$$;

comment on function postgis_scripts_installed()
is 'Returns version of the postgis scripts installed in this database.';

alter function postgis_scripts_installed()
  owner to postgres;

