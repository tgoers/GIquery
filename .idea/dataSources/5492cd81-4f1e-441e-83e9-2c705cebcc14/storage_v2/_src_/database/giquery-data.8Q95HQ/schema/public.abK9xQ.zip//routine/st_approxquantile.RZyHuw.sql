create function st_approxquantile(rast raster, nband integer, sample_percent double precision, quantile double precision)
  returns double precision
immutable
strict
language sql
as $$
SELECT ( public._ST_quantile($1, $2, TRUE, $3, ARRAY[$4]::double precision[])).value
$$;

alter function st_approxquantile(raster, integer, double precision, double precision)
  owner to postgres;

