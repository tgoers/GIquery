create function st_distance_spheroid(geom1 geometry, geom2 geometry, spheroid)
  returns double precision
immutable
strict
language sql
as $$
SELECT public._postgis_deprecate('ST_Distance_Spheroid', 'ST_DistanceSpheroid', '2.2.0');
    SELECT public.ST_DistanceSpheroid($1,$2,$3);
$$;

alter function st_distance_spheroid(geometry, geometry, spheroid)
  owner to postgres;

