create function st_buffer(text, double precision, integer)
  returns geometry
immutable
strict
language sql
as $$
SELECT public.ST_Buffer($1::public.geometry, $2, $3);
$$;

alter function st_buffer(text, double precision, integer)
  owner to postgres;

