create function st_mapalgebrafct(rast raster, pixeltype text, onerastuserfunc regprocedure)
  returns raster
language sql
as $$
SELECT public.ST_mapalgebrafct($1, 1, $2, $3, NULL)
$$;

alter function st_mapalgebrafct(raster, text, regprocedure)
  owner to postgres;

