create function lockrow(text, text, text)
  returns integer
strict
language sql
as $$
SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');
$$;

comment on function lockrow(text, text, text)
is 'args: a_table_name, a_row_key, an_auth_token - Set lock/authorization for specific row in table';

alter function lockrow(text, text, text)
  owner to postgres;

